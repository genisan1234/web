# ojet component template

## Usage
Refer to the oj.Composite jsdoc
http://www.oracle.com/webfolder/technetwork/jet/jsdocs/oj.Composite.html